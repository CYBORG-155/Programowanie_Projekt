var searchData=
[
  ['form1_19',['Form1',['../class_srednia_semestralna_1_1_form1.html',1,'SredniaSemestralna']]]
];
