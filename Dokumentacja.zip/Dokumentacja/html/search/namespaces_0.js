var searchData=
[
  ['properties_21',['Properties',['../namespace_srednia_semestralna_1_1_properties.html',1,'SredniaSemestralna']]],
  ['sredniasemestralna_22',['SredniaSemestralna',['../namespace_srednia_semestralna.html',1,'']]]
];
