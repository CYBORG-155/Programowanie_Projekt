var searchData=
[
  ['testmethod1_15',['TestMethod1',['../class_test_stypendium_1_1_unit_test1.html#a7c8707dc85a81a37de390410f42f6c9c',1,'TestStypendium::UnitTest1']]],
  ['teststypendium_16',['TestStypendium',['../namespace_test_stypendium.html',1,'']]]
];
