var searchData=
[
  ['readme_2emd_30',['readme.md',['../readme_8md.html',1,'']]],
  ['resources_2edesigner_2ecs_31',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]]
];
