var searchData=
[
  ['changes_2emd_2',['CHANGES.md',['../_c_h_a_n_g_e_s_8md.html',1,'']]],
  ['countsubjectstest_3',['countSubjectsTest',['../class_srednia_semestralna_1_1_form1.html#a41134436d1b4cbdb99ec0ec60f19a066',1,'SredniaSemestralna::Form1']]]
];
