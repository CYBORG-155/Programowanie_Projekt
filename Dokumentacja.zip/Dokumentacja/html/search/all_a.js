var searchData=
[
  ['unittest1_17',['UnitTest1',['../class_test_stypendium_1_1_unit_test1.html',1,'TestStypendium']]],
  ['unittest1_2ecs_18',['UnitTest1.cs',['../_unit_test1_8cs.html',1,'']]]
];
