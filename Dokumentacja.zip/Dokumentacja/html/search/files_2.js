var searchData=
[
  ['changes_2emd_26',['CHANGES.md',['../_c_h_a_n_g_e_s_8md.html',1,'']]]
];
