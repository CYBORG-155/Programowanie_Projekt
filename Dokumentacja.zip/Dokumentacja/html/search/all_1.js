var searchData=
[
  ['assemblyinfo_2ecs_1',['AssemblyInfo.cs',['../_srednia_semestralna_2_properties_2_assembly_info_8cs.html',1,'(Global Namespace)'],['../_test_stypendium_2_properties_2_assembly_info_8cs.html',1,'(Global Namespace)']]]
];
