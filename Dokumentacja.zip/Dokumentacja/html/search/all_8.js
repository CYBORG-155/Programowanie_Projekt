var searchData=
[
  ['properties_12',['Properties',['../namespace_srednia_semestralna_1_1_properties.html',1,'SredniaSemestralna']]],
  ['settings_2edesigner_2ecs_13',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]],
  ['sredniasemestralna_14',['SredniaSemestralna',['../namespace_srednia_semestralna.html',1,'']]]
];
