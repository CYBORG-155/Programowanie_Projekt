var searchData=
[
  ['dispose_4',['Dispose',['../class_srednia_semestralna_1_1_form1.html#a8deb129826b755d5fbece0b6f920a54e',1,'SredniaSemestralna::Form1']]]
];
