var searchData=
[
  ['readme_2emd_10',['readme.md',['../readme_8md.html',1,'']]],
  ['resources_2edesigner_2ecs_11',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]]
];
