var searchData=
[
  ['form1_36',['Form1',['../class_srednia_semestralna_1_1_form1.html#a32c5ffb42aa9204c533afadbc8782156',1,'SredniaSemestralna::Form1']]]
];
