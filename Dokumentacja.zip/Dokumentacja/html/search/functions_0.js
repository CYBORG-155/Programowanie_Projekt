var searchData=
[
  ['countsubjectstest_34',['countSubjectsTest',['../class_srednia_semestralna_1_1_form1.html#a41134436d1b4cbdb99ec0ec60f19a066',1,'SredniaSemestralna::Form1']]]
];
