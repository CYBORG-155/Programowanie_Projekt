var searchData=
[
  ['unittest1_20',['UnitTest1',['../class_test_stypendium_1_1_unit_test1.html',1,'TestStypendium']]]
];
